package com.codebyte.fullbatteryandantitheftalarm.presenter;


public interface IAlarmPresenter {
    void onChangePinClick();

    void onChangeToneClick();

    void onFlashLightSwitch(Boolean bool);

    void onVibrateSwitch(Boolean bool);
}
