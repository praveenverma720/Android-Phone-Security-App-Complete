package com.codebyte.fullbatteryandantitheftalarm.view;


public interface ICommonSettingView {
    void onAlarmSettingBtnClick();

    void onOptionSwitchClick(Boolean bool);
}
