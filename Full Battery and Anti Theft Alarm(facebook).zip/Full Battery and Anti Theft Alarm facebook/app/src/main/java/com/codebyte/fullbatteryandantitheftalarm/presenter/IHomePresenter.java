package com.codebyte.fullbatteryandantitheftalarm.presenter;


public interface IHomePresenter {
    void onChargerAlarmClick(Boolean bool);

    void onClapClick(Boolean bool);

    void onIntruderAlertClick(Boolean bool);

    void onPocketAlarmClick(Boolean bool);

    void onWhistleClick(Boolean bool);

    void onWrongPassClick(Boolean bool);
}
