package com.codebyte.fullbatteryandantitheftalarm.presenter;


public interface IIntruderAlertPresenter {
    void onActiveIntruderSwitchClick(Boolean bool);

    void onAlarmSettingBtn();

    void onAt1Click();

    void onAt2Click();

    void onAt3Click();

    void onRingAlarmSwitchClick(Boolean bool);

    void onShowIntruderAlertBtn();
}
