package com.codebyte.fullbatteryandantitheftalarm.models;


public interface IUser {
    String getPass1();

    String getPass2();

    int isValidData();
}
