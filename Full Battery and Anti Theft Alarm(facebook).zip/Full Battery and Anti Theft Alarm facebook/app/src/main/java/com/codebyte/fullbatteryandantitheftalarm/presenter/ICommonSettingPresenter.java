package com.codebyte.fullbatteryandantitheftalarm.presenter;


public interface ICommonSettingPresenter {
    void onChargerAlarmClick(Boolean bool);

    void onPocketAlarmClick(Boolean bool);
}
