package com.codebyte.fullbatteryandantitheftalarm.presenter;


public interface ILoginPresenter {
    void onLoginError(String str);

    void onLoginResult(String str);
}
