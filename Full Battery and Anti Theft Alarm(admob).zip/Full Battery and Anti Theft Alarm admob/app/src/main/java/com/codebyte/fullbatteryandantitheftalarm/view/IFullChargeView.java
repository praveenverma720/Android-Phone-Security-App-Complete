package com.codebyte.fullbatteryandantitheftalarm.view;


public interface IFullChargeView {
    void onAlarmBtnClick();

    void onOptionSwitchClick(Boolean bool);
}
