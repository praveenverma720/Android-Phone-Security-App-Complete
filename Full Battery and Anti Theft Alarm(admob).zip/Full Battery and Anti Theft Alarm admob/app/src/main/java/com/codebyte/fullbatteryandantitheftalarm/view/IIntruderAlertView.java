package com.codebyte.fullbatteryandantitheftalarm.view;


public interface IIntruderAlertView {
    void onActiveIntruderSwitchClick(Boolean bool);

    void onAlarmSettingBtn();

    void onAt1Click();

    void onAt2Click();

    void onAt3Click();

    void onRingAlarmSwitchClick(Boolean bool);

    void onShowIntruderAlertBtn();
}
