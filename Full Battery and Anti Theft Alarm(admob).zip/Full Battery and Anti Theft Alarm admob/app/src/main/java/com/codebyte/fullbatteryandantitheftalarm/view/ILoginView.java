package com.codebyte.fullbatteryandantitheftalarm.view;

import android.content.Context;


public interface ILoginView {
    void onLogin(String str, Context context);

    void onSignUp(String str, String str2, Context context);
}
