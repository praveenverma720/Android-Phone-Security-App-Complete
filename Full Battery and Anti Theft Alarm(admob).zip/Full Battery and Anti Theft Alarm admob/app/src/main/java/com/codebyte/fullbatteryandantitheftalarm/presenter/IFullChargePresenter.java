package com.codebyte.fullbatteryandantitheftalarm.presenter;


public interface IFullChargePresenter {
}
